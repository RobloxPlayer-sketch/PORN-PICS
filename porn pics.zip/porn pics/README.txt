This is malware. 
contact me on discord if u have any questions.
Wolfz#4692

(open open.bat)
(close opening exit.bat)